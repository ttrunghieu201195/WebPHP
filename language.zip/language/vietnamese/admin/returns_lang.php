<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
 * Language: English
 * Module: SMS
 *
 * Last edited:
 * 9th November 2017
 *
 * Package:
 * Stock Manage Advance v3.0
 *
 * You can translate this file to your language.
 * For instruction on new language setup, please visit the documentations.
 * You also can share your language files by emailing to saleem@tecdiary.com
 * Thank you
 */

$lang['edit_return']                        = "Chỉnh sửa trả về";
$lang['delete_return']                      = "Xóa trả về";
$lang['return_sale']                        = "Bán lại";
$lang['return_note']                        = "Ghi chú trả về";
$lang['staff_note']                         = "Ghi chú của nhân viên";
$lang['you_will_loss_return_data']          = "Bạn sẽ mát dữ liệu trả về hiện tại";
$lang['delete_returns']                     = "Xóa trả về";
$lang['staff_note']                         = "Ghi chú của nhân viên";
$lang['return_added']                       = "Trả về đã được thêm thành công";
$lang['return_updated']                     = "Trả về đã được cập nhật thành công";
$lang['return_deleted']                     = "Trả về đã bị xóa thành công";
$lang['return_x_edited_older_than_x_days']  = "Trả về cũ hơn %d ngày không thể chỉnh sửa";

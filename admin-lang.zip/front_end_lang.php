<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
 * Language: English
 * Module: Front End Settings
 *
 * Last edited:
 * 21st March 2017
 *
 * Package:
 * Stock Manage Advance v3.0
 *
 * You can translate this file to your language.
 * For instruction on new language setup, please visit the documentations.
 * You also can share your language files by emailing to support@tecdiary.com
 * Thank you
 */


$lang['shop_name']                      = "Tên cửa hàng";
$lang['page']                           = "Trang";
$lang['pages']                          = "Trang";
$lang['slug']                           = "Slug";
$lang['order']                          = "Đặt hàng";
$lang['menu_order']                     = "Thứ tự trình đơn";
$lang['body']                           = "Nội dung";
$lang['edit_page']                      = "Chỉnh sửa trang";
$lang['delete_page']                    = "Xóa trang";
$lang['delete_pages']                   = "Xóa trang";
$lang['page_added']                     = "Trang được thêm thành công";
$lang['page_updated']                   = "Trang được cập nhật thành công";
$lang['page_deleted']                   = "Trang đã xóa thành công";
$lang['pages_deleted']                  = "Trang đã xóa thành công";
$lang['order_no']                       = "Số thứ tự.";
$lang['title_required']                 = "Vui lòng nhập tiêu đề";
$lang['description_required']           = "Vui lòng nhập mô tả";
$lang['body_required']                  = "Vui lòng nhập nội dung";
$lang['about_link']                     = "Trang giới thiệu";
$lang['terms_link']                     = "Trang điều khoản";
$lang['privacy_link']                   = "Trang chính sách bảo mật";
$lang['contact_link']                   = "Trang liên hệ";
$lang['cookie_link']                    = "Trang cookie";
$lang['cookie_message']                 = "Tin nhắn cookie";
$lang['payment_text']                   = "Văn bản thanh toán";
$lang['follow_text']                    = "Văn bản theo dõi ";
$lang['facebook']                       = "Facebook";
$lang['twitter']                        = "Twitter";
$lang['google_plus']                    = "Google Plus";
$lang['instagram']                      = "Instgram";
$lang['image']                          = "Hình ảnh";
$lang['link']                           = "Liên kết";
$lang['caption']                        = "Chú thích";
$lang['show_in_top_menu']               = "Hiển thị trong các trình đơn trên cùng";
$lang['products_page']                  = "Trang sản phẩm (kiểu lưới)";
$lang['leave_gap']                      = "Để lại khoảng trống bên dưới";
$lang['re_arrange']                     = "Sắp xếp lại sản phẩm";

